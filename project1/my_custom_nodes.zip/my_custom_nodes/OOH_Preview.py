import torch
import numpy as np
from PIL import Image, ImageDraw
from ultralytics import YOLO
import cv2

# --- 辅助函数 --- #

def comfy_image_to_pil(image_tensor):
    """
    根据输入的维度和类型（IMAGE或MASK）进行相应的处理以转换为PIL图像。
    """
    if isinstance(image_tensor, torch.Tensor):
        # 如果是Tensor，先转换为numpy数组
        image_np = image_tensor.cpu().numpy()
    else:
        image_np = image_tensor

    if image_np.ndim == 4:  # 如果是批次图像
        image_np = image_np[0]  

    if image_np.shape[0] in [1, 3]:  # 判断是否为MASK或者IMAGE
        # 若为MASK(单通道)或IMAGE(三通道)，需要将通道移到最后
        image_np = np.transpose(image_np, (1, 2, 0))

    if image_np.shape[2] == 1:  # MASK的情况
        image_np = image_np.squeeze()  
    else:
        image_np = image_np * 255.0  

    image_np = np.clip(image_np, 0, 255).astype(np.uint8)
    return Image.fromarray(image_np)

def pil_to_comfy_image(pil_image):
    image_np = np.array(pil_image).astype(np.float32) / 255.0
    image_tensor = torch.from_numpy(image_np)[None,] 
    return image_tensor


# 加载模型并强制运行在 CPU 上
model = YOLO("models/ai_detector/yolov8s-seg.pt").to('cpu')

def detect_billboard_corners(image_np):
    """
    输入: NumPy 图像 (H, W, C)
    输出: 四个角点 [[x1,y1], [x2,y2], [x3,y3], [x4,y4]]
    """

    results = model(image_np)

    if not results or len(results[0].masks) == 0:
        return None  

    masks = results[0].masks.xy  # 获取所有实例的轮廓点（已经是 numpy array）

    if isinstance(masks, list):
        largest_mask = max(masks, key=lambda x: len(x))  # 取最大的轮廓
    else:
        masks = masks.data.numpy() 
        largest_mask = masks[0]

    rect = cv2.minAreaRect(largest_mask.astype(np.float32))
    box = cv2.boxPoints(rect)
    box = np.intp(box)

    box = order_points(box)

    return box.astype(np.float32)


def order_points(pts):
    """确保四边形点按顺时针排列"""
    pts = pts.tolist()
    pts.sort(key=lambda x: x[1])  # 先按 y 坐标排序
    top_two = pts[:2]
    bottom_two = pts[2:]

    top_two.sort(key=lambda x: x[0])
    bottom_two.sort(key=lambda x: x[0], reverse=True)

    return np.array(top_two + bottom_two, dtype=np.float32)

# --- 自定义节点类 --- #

class CustomNode_FourPointPerspectiveTransform:
    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "image": ("IMAGE",),
                "auto_detect": ("BOOLEAN", {"default": False}),
            },
            "optional": {
                "points_str": ("STRING", {"multiline": False, "default": "0,0,100,0,100,100,0,100", "placeholder": "x1,y1,x2,y2,x3,y3,x4,y4 (左上, 右上, 右下, 左下)"}),
                "canny_image": ("IMAGE",),
                "depth_image": ("IMAGE",),
            }
        }
    
    RETURN_TYPES = ("IMAGE", "FLOAT", "MATRIX", "MASK", "INT", "INT")
    RETURN_NAMES = ("IMAGE_FLATTENED", "ASPECT_RATIO", "PERSPECTIVE_MATRIX", "MASK", "FLATTENED_WIDTH", "FLATTENED_HEIGHT")
    FUNCTION = "transform_and_extract"
    CATEGORY = "my_custom_nodes/OOH_Preview"

    def transform_and_extract(self, image, auto_detect, points_str="", canny_image=None, depth_image=None):
        pil_image = comfy_image_to_pil(image)
        img_np = np.array(pil_image)

        src_pts = None

        if auto_detect:
            print("正在使用AI检测广告牌的四个角点...")
            src_pts = detect_billboard_corners(img_np)
            if src_pts is None:
                raise RuntimeError("AI未能检测到广告牌，请切换为手动输入模式。")
            print(f"AI检测到的点: {src_pts.tolist()}")
        else:
            if not points_str:
                raise ValueError("当auto_detect为False时，points_str不能为空。")
            try:
                points_flat = [float(p) for p in points_str.split(",")]
                if len(points_flat) != 8:
                    raise ValueError("点字符串必须包含8个逗号分隔的数字 (x1,y1,x2,y2,x3,y3,x4,y4)。")
                src_pts = np.array(points_flat).reshape(4, 2).astype(np.float32)
            except Exception as e:
                raise ValueError(f"无效的点字符串格式: {e}")

        if src_pts is None:
            raise RuntimeError("未能获取广告牌的角点。请检查输入或AI检测逻辑。")

        # 确定展平图像的尺寸
        width_top = np.linalg.norm(src_pts[0] - src_pts[1])
        width_bottom = np.linalg.norm(src_pts[3] - src_pts[2])
        height_left = np.linalg.norm(src_pts[0] - src_pts[3])
        height_right = np.linalg.norm(src_pts[1] - src_pts[2])

        target_width = int(max(width_top, width_bottom))
        target_height = int(max(height_left, height_right))

        dst_pts = np.array([
            [0, 0],
            [target_width - 1, 0],
            [target_width - 1, target_height - 1],
            [0, target_height - 1]
        ], dtype=np.float32)

        M = cv2.getPerspectiveTransform(src_pts, dst_pts)
        
        flattened_img_np = cv2.warpPerspective(img_np, M, (target_width, target_height))
        flattened_pil_image = Image.fromarray(flattened_img_np)

        aspect_ratio = float(target_width) / float(target_height)

        mask_np = np.zeros(img_np.shape[:2], dtype=np.uint8)
        cv2.fillConvexPoly(mask_np, src_pts.astype(int), 255)
        mask_pil = Image.fromarray(mask_np)

        # 返回值中增加展平图像的宽度和高度
        return (pil_to_comfy_image(flattened_pil_image), 
                aspect_ratio, 
                torch.from_numpy(M).float(), 
                pil_to_comfy_image(mask_pil),
                target_width, 
                target_height) 

class CustomNode_ApplyPerspectiveTransform:
    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "image_to_transform": ("IMAGE",), 
                "perspective_matrix": ("MATRIX",), 
                "original_image_size_ref": ("IMAGE",), 
                "flattened_width": ("INT", {"default": 512}), 
                "flattened_height": ("INT", {"default": 512}), 
            }
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("IMAGE_TRANSFORMED",)
    FUNCTION = "apply_transform"
    CATEGORY = "my_custom_nodes/OOH_Preview"

    def apply_transform(self, image_to_transform, perspective_matrix, original_image_size_ref, flattened_width, flattened_height):
        pil_poster = comfy_image_to_pil(image_to_transform)
        
        # 使用 Image.LANCZOS 进行缩放
        pil_poster = pil_poster.resize((flattened_width, flattened_height), Image.LANCZOS)

        poster_np = np.array(pil_poster)

        original_img_pil = comfy_image_to_pil(original_image_size_ref)
        original_w, original_h = original_img_pil.size 

        M_inv = np.linalg.inv(perspective_matrix.numpy())

        transformed_poster_np = cv2.warpPerspective(poster_np, M_inv, (original_w, original_h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_TRANSPARENT)

        transformed_pil_image = Image.fromarray(transformed_poster_np)
        return (pil_to_comfy_image(transformed_pil_image),)

class CustomNode_LightingAndColorAdjust:
    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "blended_image": ("IMAGE",), 
                "original_image": ("IMAGE",), 
                "mask": ("MASK",), 
                "brightness_factor": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01, "display": "slider"}),
                "contrast_factor": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01, "display": "slider"}),
                "saturation_factor": ("FLOAT", {"default": 1.0, "min": 0.0, "max": 2.0, "step": 0.01, "display": "slider"}),
            },
            "optional": {
                "depth_image": ("IMAGE",), 
            }
        }

    RETURN_TYPES = ("IMAGE",)
    RETURN_NAMES = ("IMAGE_FINAL",)
    FUNCTION = "adjust_lighting_color"
    CATEGORY = "my_custom_nodes/OOH_Preview"

    def adjust_lighting_color(self, blended_image, original_image, mask, brightness_factor, contrast_factor, saturation_factor, depth_image=None):
        blended_pil = comfy_image_to_pil(blended_image)
        original_pil = comfy_image_to_pil(original_image)
        mask_pil = comfy_image_to_pil(mask).convert("L") 

        blended_np = np.array(blended_pil)
        original_np = np.array(original_pil)
        mask_np = np.array(mask_pil)

        mask_bool = mask_np > 0

        blended_lab = cv2.cvtColor(blended_np, cv2.COLOR_RGB2LAB)

        L_channel = blended_lab[:,:,0].astype(np.float32)
        A_channel = blended_lab[:,:,1].astype(np.float32)
        B_channel = blended_lab[:,:,2].astype(np.float32)

        L_channel = L_channel * contrast_factor + (brightness_factor - 1.0) * 128 
        L_channel = np.clip(L_channel, 0, 255).astype(np.uint8)

        A_channel = (A_channel - 128) * saturation_factor + 128
        B_channel = (B_channel - 128) * saturation_factor + 128
            
        A_channel = np.clip(A_channel, 0, 255).astype(np.uint8)
        B_channel = np.clip(B_channel, 0, 255).astype(np.uint8)

        blended_lab[:,:,0] = L_channel
        blended_lab[:,:,1] = A_channel
        blended_lab[:,:,2] = B_channel

        adjusted_blended_np = cv2.cvtColor(blended_lab, cv2.COLOR_LAB2RGB)

        final_image_np = original_np.copy()
        final_image_np[mask_bool] = adjusted_blended_np[mask_bool]

        final_pil_image = Image.fromarray(final_image_np)
        return (pil_to_comfy_image(final_pil_image),)

