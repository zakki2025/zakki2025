from .OOH_Preview import CustomNode_FourPointPerspectiveTransform
from .OOH_Preview import CustomNode_ApplyPerspectiveTransform
from .OOH_Preview import CustomNode_LightingAndColorAdjust

NODE_CLASS_MAPPINGS = {
    "CustomNode_FourPointPerspectiveTransform": CustomNode_FourPointPerspectiveTransform,
    "CustomNode_ApplyPerspectiveTransform": CustomNode_ApplyPerspectiveTransform,
    "CustomNode_LightingAndColorAdjust": CustomNode_LightingAndColorAdjust
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "CustomNode_FourPointPerspectiveTransform": "四点透视变换与比例提取",
    "CustomNode_ApplyPerspectiveTransform": "应用透视变换",
    "CustomNode_LightingAndColorAdjust": "光影与色彩调整"
}